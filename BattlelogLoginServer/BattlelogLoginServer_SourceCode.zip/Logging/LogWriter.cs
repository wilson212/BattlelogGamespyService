﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
namespace Server.Logging
{
    /// <summary>
    /// Provides an object wrapper for a file that is used to
    /// store LogMessage's into. Uses a Multi-Thread safe Queueing
    /// system, and provides full Asynchronous writing and flushing
    /// </summary>
    public class LogWriter
    {
        /// <summary>
        /// Our Queue of log messages to be written, Thread safe
        /// </summary>
        private ConcurrentQueue<LogMessage> LogQueue;

        /// <summary>
        /// Full path to the log file
        /// </summary>
        private FileInfo LogFile;

        /// <summary>
        /// Our Timer object for writing to the log file
        /// </summary>
        private Timer LogTimer;

        private Timer TruncateTimer;

        private Task FlushTask;

        /// <summary>
        /// Creates a new Log Writter instance
        /// </summary>
        /// <param name="FileLocation">The location of the logfile. If the file doesnt exist,
        /// It will be created.</param>
        /// <param name="Truncate">If set to true and the logfile is over XX size, it will be truncated to 0 length</param>
        /// <param name="TruncateLen">
        ///     If <paramref name="Truncate"/> is true, The size of the file must be at least this size, 
        ///     in bytes, to truncate it
        /// </param>
        public LogWriter(string FileLocation, bool Truncate = false, int TruncateLen = 2097152)
        {
            // Set internals
            LogFile = new FileInfo(FileLocation);
            LogQueue = new ConcurrentQueue<LogMessage>();

            // Test that we are able to open and write to the file
            using (FileStream stream = LogFile.Open(FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                // If the file is over 2MB, and we want to truncate big files
                if (Truncate && LogFile.Length > TruncateLen)
                {
                    stream.SetLength(0);
                    stream.Flush();
                }
            }

            // Start a log timer, and auto write new logs every 3 seconds
            LogTimer = new Timer(3000);
            LogTimer.Elapsed += (s, e) => FlushLog();
            LogTimer.Start();

            // 24 Truncate Timer
            if (Truncate)
            {
                // Create Truncation Task
                TimeSpan untilMidnight = DateTime.Today.AddDays(1.0) - DateTime.Now;
                TruncateTimer = new Timer();
                TruncateTimer.Interval = untilMidnight.TotalMilliseconds;
                TruncateTimer.Elapsed += TruncateTimer_Elapsed;
                TruncateTimer.Start();
            }
        }

        private async void TruncateTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                // Get next 24 hours
                TruncateTimer.Stop();
                TimeSpan untilMidnight = DateTime.Today.AddDays(1.0) - DateTime.Now;
                TruncateTimer.Interval = untilMidnight.TotalMilliseconds;
                TruncateTimer.Start();

                // Wait for flush to finish
                if (FlushTask.Status == TaskStatus.Running)
                    await FlushTask;

                LogTimer.Stop();

                // Empty log
                using (FileStream stream = LogFile.Open(FileMode.OpenOrCreate, FileAccess.ReadWrite))
                {
                    stream.SetLength(0);
                    stream.Flush();
                }

                // Start timer again
                LogTimer.Start();
            }
            catch (Exception E)
            {
                ExceptionHandler.GenerateExceptionLog(E);
            }
        }

        /// <summary>
        /// Adds a message to the queue, to be written to the log file
        /// </summary>
        /// <param name="message">The message to write to the log</param>
        public void Write(string message)
        {
            // Push to the Queue
            LogQueue.Enqueue(new LogMessage(message));
        }

        /// <summary>
        /// Adds a message to the queue, to be written to the log file
        /// </summary>
        /// <param name="message">The message to write to the log</param>
        public void Write(string message, params object[] items)
        {
            LogQueue.Enqueue(new LogMessage(String.Format(message, items)));
        }

        /// <summary>
        /// Flushes the Queue to the physical log file
        /// </summary>
        private void FlushLog()
        {
            // Only log if we have a queue
            if (FlushTask == null || (FlushTask.Status != TaskStatus.Running && LogQueue.Count > 0))
            {
                // Wrap this in a task, to fire in a threadpool
                FlushTask = Task.Run(async () =>
                {
                    // Make sure file exists!
                    if (!LogFile.Exists)
                        LogFile.Open(FileMode.OpenOrCreate).Close();

                    // Append messages
                    using (FileStream fs = LogFile.Open(FileMode.Append, FileAccess.Write, FileShare.Read))
                    using (StreamWriter writer = new StreamWriter(fs, Encoding.UTF8))
                    {
                        while (LogQueue.Count > 0)
                        {
                            LogMessage entry;
                            if (LogQueue.TryDequeue(out entry))
                                await writer.WriteLineAsync(String.Format("[{0}]\t{1}", entry.LogTime, entry.Message));
                        }
                    }
                });
            }
        }

        /// <summary>
        /// Destructor. Make sure we flush!
        /// </summary>
        ~LogWriter()
        {
            LogTimer.Stop();
            LogTimer.Dispose();
            FlushLog();
        }
    }
}
